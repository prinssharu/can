<?php
include '../connect/config.php';

session_start();

// Function to display alerts
function show_alert($message, $type) {
    echo "<div class='alert alert-$type' role='alert'>$message</div>";
}

// Function to send email
function send_email_notification($email, $orderId) {
    $subject = "Order Processed";
    $message = "Your order #$orderId has been processed. Please take your order from the counter.";
    $headers = "From: no-reply@canteen.com";

    // Uncomment the line below to send email
    // mail($email, $subject, $message, $headers);
    echo "<script>alert('Email sent to customer for Order #$orderId');</script>";
}

// Check if the form is submitted for order processing
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['process_order'])) {
    $orderId = $_POST['order_id_to_process'];

    // Update order status to 'processed'
    $update_query = "UPDATE orders SET status = 'processed' WHERE order_id = $orderId";
    if (mysqli_query($conn, $update_query)) {
        // Alert: Order processing successful
        show_alert("Order processed. Notification will be sent in 10 minutes.", "success");

        // Trigger JavaScript timer for the 10-minute delay
        echo "<script>
            setTimeout(function() {
                alert('Customer notified for Order #$orderId');
                send_email_notification('$row[email]', $orderId);
            }, 60000); // 60000 ms = 1 minutes
        </script>";
    } else {
        // Alert: Error in order processing
        show_alert("Error processing order: " . mysqli_error($conn), "danger");
    }
}

// Check if the delete button is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_order'])) {
    $orderId = $_POST['order_id_to_delete'];

    // Delete the order from the database
    $delete_query = "DELETE FROM orders WHERE order_id = $orderId";
    if (mysqli_query($conn, $delete_query)) {
        show_alert("Order deleted successfully.", "success");
    } else {
        show_alert("Error deleting order: " . mysqli_error($conn), "danger");
    }
}

// Fetch orders data from the database
$query = "SELECT * FROM orders";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Fast Food Resturant- Manage Orders</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container-xxl bg-white p-0">
        <div class="row mt-5">
            <div class="col-md-10 mx-auto">
                <h2 class="text-center mb-4">Manage Orders</h2>
                
                <!-- Orders Table -->
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Customer Name</th>
                            <th scope="col">Item Name</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Total Amount</th>
                            <th scope="col">Status</th>
                            <th scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                ?>
                                <tr>
                                    <td><?php echo $row['order_id']; ?></td>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['item_name']; ?></td>
                                    <td><?php echo $row['quantity']; ?></td>
                                    <td><?php echo $row['total_price']; ?></td>
                                    <td><?php echo $row['status']; ?></td>
                                    <td>
                                        <form method="POST">
                                            <input type="hidden" name="order_id_to_process" value="<?php echo $row['order_id']; ?>">
                                            <button type="submit" name="process_order" class="btn btn-sm btn-success">Process</button>
                                            <input type="hidden" name="order_id_to_delete" value="<?php echo $row['order_id']; ?>">
                                            <button type="submit" name="delete_order" class="btn btn-sm btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo "<tr><td colspan='7'>No orders found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
