<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['new_logo'])) {
    $uploadDir = 'uploads/'; // Folder to save the uploaded logo
    $uploadFile = $uploadDir . basename($_FILES['new_logo']['name']);

    // Check if the uploads folder exists, if not, create it
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Move the uploaded file to the designated folder
    if (move_uploaded_file($_FILES['new_logo']['tmp_name'], $uploadFile)) {
        echo "Logo successfully updated!";
    } else {
        echo "Error uploading the file.";
    }
} else {
    echo "No file uploaded.";
}
?>
