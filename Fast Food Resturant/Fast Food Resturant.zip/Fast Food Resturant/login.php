<?php
include 'connect/config.php';

session_start(); // Start the session

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM users WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Set session variables
            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['user_email'] = $row['email'];
            $_SESSION['user_type'] = $row['user_type'];
            $_SESSION['user_name'] = $row['name'];

            // Check the user type
            if ($row['user_type'] === 'admin') {
                header("Location: admin/dashboard.php"); // Redirect admin to admin dashboard
                exit();
            } else {
                header("Location: home.php"); // Redirect regular user to home.php
                exit();
            }
        } else {
            // echo "Invalid password!";
            echo "<script>alert('Invalid password!'); window.location.href='signin.php';</script>";

        }
    } else {
        // echo "No user found with this email!";
        echo "<script>alert('No user found with this email!'); window.location.href='signin.php';</script>";

    }

    $conn->close();
}
?>
